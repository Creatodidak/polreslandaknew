@extends('layout/master')
@section('content')

@foreach($data as $d)
    <section class="pt-2 flex flex-col px-2 gap-2">
        <nav class="flex mt-4 px-5 py-3 text-gray-700 border rounded-lg bg-gray-800 border-gray-700 md:w-3/4 3xl:w-full md:m-auto"
            aria-label="Breadcrumb">
            <ol class="inline-flex items-center space-x-1 md:space-x-3">
                <li class="inline-flex items-center">
                    <a href="{{ URL::to('/') }}"
                        class="inline-flex items-center text-sm font-medium hover:text-blue-600 text-gray-400">
                        <svg aria-hidden="true" class="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 20 20"
                            xmlns="http://www.w3.org/2000/svg">
                            <path
                                d="M10.707 2.293a1 1 0 00-1.414 0l-7 7a1 1 0 001.414 1.414L4 10.414V17a1 1 0 001 1h2a1 1 0 001-1v-2a1 1 0 011-1h2a1 1 0 011 1v2a1 1 0 001 1h2a1 1 0 001-1v-6.586l.293.293a1 1 0 001.414-1.414l-7-7z">
                            </path>
                        </svg>
                        HOME
                    </a>
                </li>
                <li>
                    <div class="flex items-center">
                        <svg aria-hidden="true" class="w-6 h-6 text-gray-400" fill="currentColor" viewBox="0 0 20 20"
                            xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd"
                                d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z"
                                clip-rule="evenodd"></path>
                        </svg>
                        <p class="ml-1 text-sm font-medium md:ml-2 text-gray-400"><?= $d->satker ?>
                        </p>
                    </div>
                </li>
                <li aria-current="page">
                    <div class="flex items-center">
                        <svg aria-hidden="true" class="w-6 h-6 text-gray-400" fill="currentColor" viewBox="0 0 20 20"
                            xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd"
                                d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z"
                                clip-rule="evenodd"></path>
                        </svg>
                        <span
                            class="ml-1 text-sm font-medium md:ml-2 text-gray-400"><?= $d->kategori ?></span>
                    </div>
                </li>
            </ol>
        </nav>

        <div class="flex flex-col md:w-3/4 3xl:w-full md:m-auto p-5 rounded-lg mt-2 bg-gray-800">
            <h1 class="text-gray-200 font-bold text-xl md:text-3xl text-center"><?= $d->judul ?>
            </h1>
            <div class="flex flex-row h-6 justify-center items-center m-3">
                <img src="{{ url('/assets/img/humas.png') }}" class="h-full" alt="">
                <p class="text-lg text-gray-500"> HUMAS <?= $d->satker ?> | |
                    <?= \Carbon\Carbon::parse($d->create_at)->diffForHumans() ?></p>
            </div>
            <figure class="w-full md:w-3/4 mx-auto">
                <img src="{{ URL::to('/') }}/<?= $d->foto ?>" class="w-full rounded-md" alt="">
                <figcaption class="text-gray-500 text-sm italic">
                    <p><?= $d->caption ?></p>
                </figcaption>
            </figure>
            <div id="isiberita" class="text-gray-100 text-justify text-base flex flex-col gap-5 p-4 indent-12">
                <?= $d->isi ?>
            </div>

            <div id="author" class="text-gray-100 text-justify text-base flex flex-col gap-1 p-4">
                <p>Ditulis Oleh: <?= $d->penulis ?></p>
                <p>Dipublikasikan Oleh: <?= $d->namapublisher ?></p>
                <p><?= \Carbon\Carbon::parse($d->create_at)->format('l, d F Y')?> |
                    <?= \Carbon\Carbon::parse($d->create_at)->diffForHumans() ?></p>
            </div>
            <div class="flex flex-col ml-9 text-gray-200 gap-2">
                <p>Baca Juga:</p>
                @foreach($other as $o)
                    <a href="/berita/<?= $o->link ?>">
                        <h1 class="text-base md:text-lg font-semibold text-justify uppercase">&#9758; <?= $o->judul ?>
                        </h1>
                    </a>
                @endforeach
            </div>
            <div class="flex flex-col justify-center">
                <p class="text-gray-400 text-lg text-center">BAGIKAN BERITA INI:</p>
                <div class="flex justify-center items-center flex-wrap space-x-2">
                    <!-- Facebook -->
                    <button type="button" data-mdb-ripple="true" data-mdb-ripple-color="light"
                        class="inline-block px-6 py-2.5 mb-2 text-white font-medium text-xs leading-tight uppercase rounded shadow-md hover:shadow-lg focus:shadow-lg focus:outline-none focus:ring-0 active:shadow-lg transition duration-150 ease-in-out"
                        style="background-color: #1877f2;">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512" class="w-4 h-4">
                            <path fill="currentColor"
                                d="M279.14 288l14.22-92.66h-88.91v-60.13c0-25.35 12.42-50.06 52.24-50.06h40.42V6.26S260.43 0 225.36 0c-73.22 0-121.08 44.38-121.08 124.72v70.62H22.89V288h81.39v224h100.17V288z" />
                        </svg>
                    </button>

                    <!-- Telegram -->
                    <button type="button" data-mdb-ripple="true" data-mdb-ripple-color="light"
                        class="inline-block px-6 py-2.5 mb-2 text-white font-medium text-xs leading-tight uppercase rounded shadow-md hover:shadow-lg focus:shadow-lg focus:outline-none focus:ring-0 active:shadow-lg transition duration-150 ease-in-out"
                        style="background-color: #0088cc;">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 496 512" class="w-4 h-4">
                            <path fill="currentColor"
                                d="M248,8C111.033,8,0,119.033,0,256S111.033,504,248,504,496,392.967,496,256,384.967,8,248,8ZM362.952,176.66c-3.732,39.215-19.881,134.378-28.1,178.3-3.476,18.584-10.322,24.816-16.948,25.425-14.4,1.326-25.338-9.517-39.287-18.661-21.827-14.308-34.158-23.215-55.346-37.177-24.485-16.135-8.612-25,5.342-39.5,3.652-3.793,67.107-61.51,68.335-66.746.153-.655.3-3.1-1.154-4.384s-3.59-.849-5.135-.5q-3.283.746-104.608,69.142-14.845,10.194-26.894,9.934c-8.855-.191-25.888-5.006-38.551-9.123-15.531-5.048-27.875-7.717-26.8-16.291q.84-6.7,18.45-13.7,108.446-47.248,144.628-62.3c68.872-28.647,83.183-33.623,92.511-33.789,2.052-.034,6.639.474,9.61,2.885a10.452,10.452,0,0,1,3.53,6.716A43.765,43.765,0,0,1,362.952,176.66Z" />
                        </svg>
                    </button>

                    <!-- Twitter -->
                    <button type="button" data-mdb-ripple="true" data-mdb-ripple-color="light"
                        class="inline-block px-6 py-2.5 mb-2 text-white font-medium text-xs leading-tight uppercase rounded shadow-md hover:shadow-lg focus:shadow-lg focus:outline-none focus:ring-0 active:shadow-lg transition duration-150 ease-in-out"
                        style="background-color: #1da1f2;">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" class="w-4 h-4">
                            <path fill="currentColor"
                                d="M459.37 151.716c.325 4.548.325 9.097.325 13.645 0 138.72-105.583 298.558-298.558 298.558-59.452 0-114.68-17.219-161.137-47.106 8.447.974 16.568 1.299 25.34 1.299 49.055 0 94.213-16.568 130.274-44.832-46.132-.975-84.792-31.188-98.112-72.772 6.498.974 12.995 1.624 19.818 1.624 9.421 0 18.843-1.3 27.614-3.573-48.081-9.747-84.143-51.98-84.143-102.985v-1.299c13.969 7.797 30.214 12.67 47.431 13.319-28.264-18.843-46.781-51.005-46.781-87.391 0-19.492 5.197-37.36 14.294-52.954 51.655 63.675 129.3 105.258 216.365 109.807-1.624-7.797-2.599-15.918-2.599-24.04 0-57.828 46.782-104.934 104.934-104.934 30.213 0 57.502 12.67 76.67 33.137 23.715-4.548 46.456-13.32 66.599-25.34-7.798 24.366-24.366 44.833-46.132 57.827 21.117-2.273 41.584-8.122 60.426-16.243-14.292 20.791-32.161 39.308-52.628 54.253z" />
                        </svg>
                    </button>

                    <!-- Whatsapp -->
                    <button type="button" data-mdb-ripple="true" data-mdb-ripple-color="light"
                        class="inline-block px-6 py-2.5 mb-2 text-white font-medium text-xs leading-tight uppercase rounded shadow-md hover:shadow-lg focus:shadow-lg focus:outline-none focus:ring-0 active:shadow-lg transition duration-150 ease-in-out"
                        style="background-color: #128c7e;">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" class="w-4 h-4">
                            <path fill="currentColor"
                                d="M380.9 97.1C339 55.1 283.2 32 223.9 32c-122.4 0-222 99.6-222 222 0 39.1 10.2 77.3 29.6 111L0 480l117.7-30.9c32.4 17.7 68.9 27 106.1 27h.1c122.3 0 224.1-99.6 224.1-222 0-59.3-25.2-115-67.1-157zm-157 341.6c-33.2 0-65.7-8.9-94-25.7l-6.7-4-69.8 18.3L72 359.2l-4.4-7c-18.5-29.4-28.2-63.3-28.2-98.2 0-101.7 82.8-184.5 184.6-184.5 49.3 0 95.6 19.2 130.4 54.1 34.8 34.9 56.2 81.2 56.1 130.5 0 101.8-84.9 184.6-186.6 184.6zm101.2-138.2c-5.5-2.8-32.8-16.2-37.9-18-5.1-1.9-8.8-2.8-12.5 2.8-3.7 5.6-14.3 18-17.6 21.8-3.2 3.7-6.5 4.2-12 1.4-32.6-16.3-54-29.1-75.5-66-5.7-9.8 5.7-9.1 16.3-30.3 1.8-3.7.9-6.9-.5-9.7-1.4-2.8-12.5-30.1-17.1-41.2-4.5-10.8-9.1-9.3-12.5-9.5-3.2-.2-6.9-.2-10.6-.2-3.7 0-9.7 1.4-14.8 6.9-5.1 5.6-19.4 19-19.4 46.3 0 27.3 19.9 53.7 22.6 57.4 2.8 3.7 39.1 59.7 94.8 83.8 35.2 15.2 49 16.5 66.6 13.9 10.7-1.6 32.8-13.4 37.4-26.4 4.6-13 4.6-24.1 3.2-26.4-1.3-2.5-5-3.9-10.5-6.6z" />
                        </svg>
                    </button>
                </div>
            </div>
            <section class="bg-gray-900 py-8" id="komentarsec">
                <div class=" mx-auto px-4">
                    <div class="flex justify-between items-center mb-6">
                        <h2 class="text-lg lg:text-2xl font-bold text-white">Komentar
                            (<?= $komentar->count() ?>)</h2>
                    </div>

                    <?php if(request()->session()->get('success') != null){?>
                        <div id="alert-3"
                        class="flex p-4 mb-4 text-green-800 rounded-lg bg-green-50"
                        role="alert">
                        <svg aria-hidden="true" class="flex-shrink-0 w-5 h-5" fill="currentColor" viewBox="0 0 20 20"
                            xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd"
                                d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z"
                                clip-rule="evenodd"></path>
                        </svg>
                        <span class="sr-only">Info</span>
                        <div class="ml-3 text-sm font-medium">
                            Berhasil mengomentari berita
                        </div>
                        <button type="button"
                            class="ml-auto -mx-1.5 -my-1.5 rounded-lg focus:ring-2 focus:ring-green-400 p-1.5 inline-flex h-8 w-8 bg-gray-800 text-green-400 hover:bg-gray-700"
                            data-dismiss-target="#alert-3" aria-label="Close">
                            <span class="sr-only">Close</span>
                            <svg aria-hidden="true" class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20"
                                xmlns="http://www.w3.org/2000/svg">
                                <path fill-rule="evenodd"
                                    d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"
                                    clip-rule="evenodd"></path>
                            </svg>
                        </button>
                    </div>
                    <?php } ?>

                    <?php if(request()->session()->get('error') != null){?>
                        <div id="alert-2"
                        class="flex p-4 mb-4 rounded-lg bg-gray-800 text-red-400"
                        role="alert">
                        <svg aria-hidden="true" class="flex-shrink-0 w-5 h-5" fill="currentColor" viewBox="0 0 20 20"
                            xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd"
                                d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z"
                                clip-rule="evenodd"></path>
                        </svg>
                        <span class="sr-only">Info</span>
                        <div class="ml-3 text-sm font-medium">
                            Gagal Mengomentari Berita
                        </div>
                        <button type="button"
                            class="ml-auto -mx-1.5 -my-1.5 rounded-lg focus:ring-2 focus:ring-red-400 p-1.5 inline-flex h-8 w-8 bg-gray-800 text-red-400 hover:bg-gray-700"
                            data-dismiss-target="#alert-2" aria-label="Close">
                            <span class="sr-only">Close</span>
                            <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20"
                                xmlns="http://www.w3.org/2000/svg">
                                <path fill-rule="evenodd"
                                    d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"
                                    clip-rule="evenodd"></path>
                            </svg>
                        </button>
                    </div>
                    <?php } ?>

                    
                    
                    <form class="mb-6" method="post" action="/berita/komentar/<?= request()->segment(2) ?>">
                        @csrf
                        <div
                            class="py-2 px-4 mb-4 rounded-lg rounded-t-lg border bg-gray-800 border-gray-700">
                            <input type="text" id="nama" name="nama"
                                class="px-0 w-full text-sm border-0 focus:ring-0 focus:outline-none text-white placeholder-gray-400 bg-gray-800"
                                placeholder="Nama Anda" required>
                        </div>
                        <div
                            class="py-2 px-4 mb-4 rounded-lg rounded-t-lg border bg-gray-800 border-gray-700">
                            <textarea id="komentar" name="komentar" rows="6"
                                class="px-0 w-full text-sm border-0 focus:ring-0 focus:outline-none text-white placeholder-gray-400 bg-gray-800"
                                placeholder="Berkomentarlah dengan tetap mempedomani norma yang berlaku"
                                required></textarea>
                        </div>
                        <button type="submit"
                            class="inline-flex items-center py-2.5 px-4 text-xs font-medium text-center text-white bg-primary-700 rounded-lg focus:ring-4 focus:ring-primary-900 hover:bg-primary-800">
                            Komentari
                        </button>
                    </form>

                    @forelse($komentar->limit(10)->get() as $k)
                        <article
                            class="p-6 mb-6 text-base border-t border-gray-700 bg-gray-900">
                            <footer class="flex justify-between items-center mb-2">
                                <div class="flex items-center">
                                    <p class="inline-flex items-center mr-3 text-sm text-white"><img
                                            class="mr-2 w-6 h-6 rounded-full"
                                            src="https://icon-library.com/images/anonymous-icon/anonymous-icon-3.jpg"
                                            alt="Bonnie Green"><?= strtoupper($k->nama) ?></p>
                                    <p class="text-sm text-gray-400"><?= \Carbon\Carbon::parse($k->created_at)->diffForHumans() ?></p>
                                </div>
                            </footer>
                            <p class="text-gray-400"><?= $k->komentar ?></p>
                        </article>
                    @empty
                        <p class="text-xl text-gray-400 font-bold text-center">BELUM ADA KOMENTAR</p>
                        <p class="text-base text-gray-400 font-bold text-center">Jadilah Orang Pertama Yang Berkomentar!
                        </p>
                    @endforelse
                </div>
            </section>
        </div>
    </section>
@endforeach


@endsection

@section('script')

<script src="https://apps.elfsight.com/p/platform.js" defer></script>

<script>

</script>
@endsection
